import { Navigate, Outlet, Link, useLocation } from "react-router-dom";
import { AuthContext } from "../App";
import React from "react";
import { AgentsIcon, ImmigrantIcon, PiroguesIcon, StatsIcon } from "./icons";
import { DisconnectButton } from "./buttons";

function NavItem({
  to,
  children,
  icon,
}: {
  to: string;
  icon: React.ReactNode;
  children: React.ReactNode;
}) {
  const { pathname } = useLocation();
  const isActive = pathname === to;
  return (
    <li>
      <Link
        className={`flex flex-row gap-x-2 rounded-md p-3 text-sm font-semibold transition-all duration-100 ${isActive ? "bg-primaryLight2 text-primary" : "bg-transparent text-gray"}`}
        to={to}
      >
        <span className={` ${isActive ? "fill-primary " : "fill-gray"}`}>
          {icon}
        </span>
        {children}
      </Link>
    </li>
  );
}

export function AdminProtectedLayout() {
  const authContext = React.useContext(AuthContext);
  if (!authContext.authData || !authContext.authData.user.is_admin) {
    return <Navigate to="/" />;
  }
  return (
    <div className="flex flex-row ">
      <ul className="flex h-screen w-[14%] flex-col gap-y-2 bg-primaryLight px-6 pt-20">
        <h3
          onClick={() => {
            authContext.logOut();
          }}
          className="mb-10 font-semibold text-gray"
        >
          Menu
        </h3>
        <NavItem to="/admin/" icon={<StatsIcon />}>
          Statistiques
        </NavItem>
        <NavItem to="/admin/agents" icon={<AgentsIcon />}>
          Agents
        </NavItem>
        <NavItem to="/admin/pirogues" icon={<PiroguesIcon />}>
          Pirogues
        </NavItem>
        <NavItem to="/admin/immigrants" icon={<ImmigrantIcon />}>
          Immigrants
        </NavItem>
        <DisconnectButton
          className="text-semibold mb-20 mt-auto self-center"
          onClick={() => {
            authContext.logOut();
          }}
        />
      </ul>
      <section className="mx-10 mt-10 flex-1">
        <Outlet />
      </section>
    </div>
  );
}
