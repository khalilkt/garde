export function Dialog({
  children,
  isOpen,
  title,
  onClose,
}: {
  children: React.ReactNode;
  isOpen: boolean;
  title: string;
  onClose: () => void;
}) {
  if (!isOpen) {
    return null;
  }
  return (
    <div className={isOpen ? "" : "hidden"}>
      <div
        onClick={onClose}
        className={`fixed inset-0 z-20 flex items-center justify-center bg-gray opacity-70 `}
      ></div>
      <div className="fixed left-1/2 top-1/2 z-20 w-max -translate-x-1/2 -translate-y-1/2 rounded-2xl bg-white px-6  py-8 shadow-lg">
        <h2 className="pb-9 text-xl font-semibold">{title}</h2>
        {children}
      </div>
    </div>
  );
}
