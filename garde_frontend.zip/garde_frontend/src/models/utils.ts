export const ss = 1;
