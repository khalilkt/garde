import React, { useContext, useEffect } from "react";
import { PirogueInterface } from "./agent&admin_pirogues_page";
import {
  Border,
  Input,
  SearchSelect,
  Select,
  Textarea,
  Title,
} from "../../components/comps";
import axios from "axios";
import { PaginatedData, roorUrl } from "../../models/constants";
import { useParams, useSearchParams } from "react-router-dom";
import { AuthContext } from "../../App";
import { ImmigrantInterface } from "./admin_immigrants_page";
import { Pagination, TableBodySquelette, Td, Tr } from "../../components/table";
import { FilledButton } from "../../components/buttons";
import { Dialog } from "../../components/dialog";
import Webcam, { WebcamProps } from "react-webcam";

function Squelette({ width }: { width: string }) {
  return (
    <div className={`h-6  animate-pulse rounded bg-[#D9D9D9] ${width}`}></div>
  );
}

function AddEditImmigrantDialog({
  pirogueId,
  onDone,
}: {
  pirogueId: string;
  onDone: () => void;
}) {
  const webcamRef = React.useRef<Webcam>(null);
  const [ss, setSs] = React.useState<string>("");
  const [formData, setFormData] = React.useState<{
    first_name: string;
    last_name: string;
    date_of_birth: string;
    is_male: boolean | null;
    image: string | null;
    birth_country: number | null;
    nationality: number | null;
    pirogue: string;
  }>({
    first_name: "",
    last_name: "",
    date_of_birth: "",
    is_male: null,
    image: null,
    birth_country: null,
    nationality: null,
    pirogue: pirogueId,
  });
  const countriesNameCache = React.useRef<{ [key: number]: string }>({});
  const token = useContext(AuthContext).authData?.token;
  const base64ToBlob = (base64String: string) => {
    const byteCharacters = atob(base64String);
    const byteNumbers = new Array(byteCharacters.length);
    for (let i = 0; i < byteCharacters.length; i++) {
      byteNumbers[i] = byteCharacters.charCodeAt(i);
    }
    const byteArray = new Uint8Array(byteNumbers);
    return new Blob([byteArray], { type: "image/jpeg" });
  };

  async function createImmigrant() {
    try {
      // check if all fields are filled
      if (
        !formData.first_name ||
        !formData.last_name ||
        !formData.date_of_birth ||
        formData.is_male === null ||
        !formData.birth_country
      ) {
        alert("Veuillez remplir tous les champs");
        return;
      }

      const imageSrc = webcamRef.current!.getScreenshot()!;
      const image = base64ToBlob(imageSrc.split(",")[1]);
      let sendFormData = new FormData();
      sendFormData.append("first_name", formData.first_name);
      sendFormData.append("last_name", formData.last_name);
      sendFormData.append("date_of_birth", formData.date_of_birth);
      sendFormData.append("is_male", formData.is_male?.toString() ?? "");
      sendFormData.append("image", image, "image.jpeg");
      sendFormData.append(
        "birth_country",
        formData.birth_country?.toString() ?? "",
      );
      sendFormData.append(
        "nationality",
        formData.nationality?.toString() ?? "",
      );
      sendFormData.append("pirogue", pirogueId);

      const response = await axios.post(
        roorUrl + "pirogues/" + pirogueId + "/immigrants/",
        sendFormData,
        {
          headers: {
            "Content-Type": "multipart/form-data",
            Authorization: `Token ${token}`,
          },
        },
      );
      console.log(response);
      onDone();
    } catch (e) {
      console.log(e);
      alert("Une erreur s'est produite");
      console.error(e);
    }
  }

  return (
    <div className="grid grid-cols-2 gap-x-4 gap-y-6">
      <div className="col-span-2 flex items-center justify-center rounded">
        <Webcam
          ref={webcamRef}
          id="webcam_id"
          className="h-40 rounded-xl"
          audio={false}
          screenshotFormat="image/jpeg"
          videoConstraints={{
            facingMode: "environment",
          }}
        />
      </div>
      <Input
        className=""
        value={formData.first_name}
        onChange={(e) => {
          setFormData({ ...formData, first_name: (e as any).target.value });
        }}
        placeholder="Prénom"
        type="text"
      />
      <Input
        className=""
        value={formData.last_name}
        onChange={(e) => {
          setFormData({ ...formData, last_name: (e as any).target.value });
        }}
        placeholder="Nom"
        type="text"
      />

      <SearchSelect<CountryInterface>
        value={
          formData.nationality
            ? countriesNameCache.current[formData.nationality]
            : null
        }
        onSelected={function (value): void {
          countriesNameCache.current[value.id] = value.name_fr;
          setFormData({ ...formData, nationality: value.id });
        }}
        placeHolder={"Nationalité"}
        search={true}
        url={"countries"}
        lookupColumn="name_fr"
      />
      <SearchSelect<CountryInterface>
        value={
          formData.birth_country
            ? countriesNameCache.current[formData.birth_country]
            : null
        }
        onSelected={function (value): void {
          countriesNameCache.current[value.id] = value.name_fr;
          setFormData({ ...formData, birth_country: value.id });
        }}
        placeHolder={"Pays de naissance"}
        search={true}
        url={"countries"}
        lookupColumn="name_fr"
      />
      <Select
        value={
          formData.is_male === null
            ? "none"
            : formData.is_male
              ? "true"
              : "false"
        }
        onChange={(e) => {
          setFormData({
            ...formData,
            is_male: (e as any).target.value === "true",
          });
        }}
      >
        <option className="text-gray" value={"none"} disabled>
          Genre
        </option>
        <option value={"true"}>Homme</option>
        <option value={"false"}>Femme</option>
      </Select>
      <Input
        className=""
        value={formData.date_of_birth}
        onChange={(e) => {
          setFormData({ ...formData, date_of_birth: (e as any).target.value });
        }}
        placeholder="Date de naissance"
        type="date"
      />

      <Textarea
        id={DESCRIPTION_TEXTAREA_ID}
        className=" col-span-2"
        placeholder="Description"
      />
      <FilledButton
        onClick={() => {
          onDone();
        }}
        isLight={true}
        className="col-span-1"
      >
        Annuler
      </FilledButton>
      <FilledButton onClick={createImmigrant} className="col-span-1">
        Créer Immigrant
      </FilledButton>
    </div>
  );
}

export interface DialogState {
  state: "none" | "adding" | "editing";
  payload?: {
    [key: string]: any;
  };
}
export interface CountryInterface {
  id: number;
  name_fr: string;
  code: string;
}

const FIRSTNAME_INPUT_ID = "firstname_dialog";
const LASTNAME_INPUT_ID = "lastname_dialog";
const NATIONALITY_INPUT_ID = "nationality_dialog";
const BIRTH_COUNTRY_INPUT_ID = "birth_country_dialog";
const DATE_OF_BIRTH_INPUT_ID = "date_of_birth_dialog";
const DESCRIPTION_TEXTAREA_ID = "description_dialog";

export default function PirogueDetailPage({
  pirogueId,
  onCloseClick,
  ...divProps
}: {
  pirogueId: string;
  onCloseClick: () => void;
} & React.HTMLProps<HTMLDivElement>) {
  const [data, setData] = React.useState<PirogueInterface | null>(null);
  const [immigrantsData, setImmigrantsData] =
    React.useState<PaginatedData<ImmigrantInterface> | null>(null);

  const [searchParams, setSearchParams] = useSearchParams();

  const token = useContext(AuthContext).authData?.token;
  const [dialogState, setDialogState] = React.useState<DialogState>({
    state: "none",
  });

  async function createImmigrant() {
    const elem = document.getElementById("ajdajdasdad");
    try {
    } catch (e) {
      console.log(e);
      alert("Error");
    }
  }

  useEffect(() => {
    load();
    loadImmigrants();
  }, [pirogueId]);

  async function load() {
    try {
      const response = await axios.get(roorUrl + "pirogues/" + pirogueId, {
        headers: {
          Authorization: `Token ${token}`,
        },
      });
      setData(response.data);
    } catch (e) {
      console.log(e);
    }
  }
  async function loadImmigrants() {
    try {
      const response = await axios.get(
        roorUrl + "pirogues/" + pirogueId + "/immigrants",
        {
          headers: {
            Authorization: `Token ${token}`,
          },
        },
      );
      setImmigrantsData(response.data);
    } catch (e) {
      console.log(e);
    }
  }

  return (
    <div
      {...divProps}
      className={`flex flex-col px-9 pt-12 ${divProps.className ?? ""}`}
    >
      <Dialog
        onClose={() => setDialogState({ state: "none" })}
        isOpen={dialogState.state !== "none"}
        title={
          dialogState.state === "editing"
            ? "Modifier Immigrant"
            : "Ajouter Immigrant"
        }
      >
        <AddEditImmigrantDialog
          onDone={() => {
            setDialogState({ state: "none" });
            loadImmigrants();
          }}
          pirogueId={pirogueId}
        />
      </Dialog>
      <div className="flex justify-between">
        {data ? (
          <Title className="mb-7">{data?.number}</Title>
        ) : (
          <Squelette width="w-10 mb-7" />
        )}
        {/* close icon */}
        <button onClick={onCloseClick}>
          <svg
            xmlns="http://www.w3.org/2000/svg"
            className="h-6 w-6 cursor-pointer stroke-gray"
            fill="none"
            viewBox="0 0 24 24"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M6 18L18 6M6 6l12 12"
            />
          </svg>
        </button>
      </div>
      {
        <div className="mb-4 flex w-full flex-row">
          <div className="grid grid-cols-2 gap-x-4 gap-y-4">
            <h3>Agent:</h3>
            {data ? (
              <Border className="text-xs">{data.created_by_name}</Border>
            ) : (
              <Squelette width="w-20" />
            )}
            <h3>Nbre d'immigrés:</h3>
            {data ? (
              <Border className="text-xs">{data.immigrants_count}</Border>
            ) : (
              <Squelette width="w-20" />
            )}
          </div>
          <div className="grid grid-cols-2 gap-x-4 gap-y-4 ">
            <h3>Lieu de Départ:</h3>
            {data ? (
              <Border className="text-xs">{data.departure}</Border>
            ) : (
              <Squelette width="w-20" />
            )}
            <h3>Destination:</h3>
            {data ? (
              <Border className="text-xs">{data.destination}</Border>
            ) : (
              <Squelette width="w-20" />
            )}
          </div>
        </div>
      }
      <hr className="border-[#888888]" />
      <Title className="mb-4 mt-6">Description</Title>
      {data ? (
        <p className="text-lg text-gray">{data?.description}</p>
      ) : (
        <div className="h-12 w-full animate-pulse rounded bg-[#D9D9D9]"></div>
      )}
      <hr className="mt-6 border-[#888888]" />
      <div className="flex items-center justify-between">
        <Title className="mb-4 mt-6">Immigrants</Title>
        <FilledButton
          className="h-max rounded-md bg-primaryLight2 px-4 py-1 text-base font-semibold text-primary"
          onClick={() => {
            setDialogState({ state: "adding" });
          }}
        >
          <span className="text-primary">Ajouter</span>
        </FilledButton>
      </div>
      <table className="text-md w-full text-center font-medium">
        <thead className="w-full">
          <tr className="font-bold text-gray">
            <th className="text-medium  py-3 text-base">Nom</th>
            <th className="text-medium  py-3 text-base">Genre</th>
            <th className="text-medium py-3 text-base">Nationalité</th>
            <th className="text-medium py-3 text-base">Pays de naissance</th>
            <th className="text-medium py-3 text-base">Date de naissance</th>
          </tr>
        </thead>
        {!immigrantsData ? (
          <TableBodySquelette columnCount={5} />
        ) : (
          <tbody>
            {immigrantsData?.data.map((immigrant, i) => (
              <Tr>
                {/* <Td>
                    <input type="checkbox" className="h-5 w-5" />
                  </Td> */}
                <Td isSmall={true}>
                  {immigrant.first_name + " " + immigrant.last_name}
                </Td>
                <Td isSmall={true}>{immigrant.is_male ? "Homme" : "Femme"}</Td>
                <Td isSmall={true}>
                  <Border className="text-xs">
                    {immigrant.nationality_name}
                  </Border>
                </Td>
                <Td isSmall={true}>
                  <Border>{immigrant.birth_country_name}</Border>
                </Td>
                <Td isSmall={true}>{immigrant.date_of_birth}</Td>
              </Tr>
            ))}
          </tbody>
        )}
      </table>
      <Pagination
        className="mt-10"
        onItemClick={(page) => {
          setSearchParams((params) => {
            params.set("selected_pirogue_imm_page", page.toString());
            return params;
          });
        }}
        current={
          searchParams.get("selected_pirogue_imm_page")
            ? parseInt(searchParams.get("selected_pirogue_imm_page")!)
            : 1
        }
        total={immigrantsData?.total_pages ?? 1}
      />
    </div>
  );
}
