import { ApexOptions } from "apexcharts";
import ReactApexChart from "react-apexcharts";
import { SearchSelect, Select, Title } from "../../components/comps";
import React from "react";
import { CountryInterface } from "./pirogue_detail_page";

export default function AdminStatsPage() {
  const countriesNameCache = React.useRef<{ [key: number]: string }>({});
  const [selectedNationality, setSelectedNationality] = React.useState<
    number | null
  >(null);
  const [selectedBirthCountry, setSelectedBirthCountry] = React.useState<
    number | null
  >(null);
  const [selectedGenre, setSelectedGenre] = React.useState<
    "none" | "male" | "female"
  >("none");
  const [selectedAge, setSelectedAge] = React.useState<
    "none" | "mineur" | "majeur"
  >("none");
  const state = {
    series: [
      {
        name: "Pirogues",
        data: [2.3, 3.1, 4.0, 10.1, 4.0, 3.6, 3.2, 2.3, 1.4, 0.8, 0.5, 0.2],
      },
      {
        name: "Immigrants",
        data: [2.3, 3.1, 4.0, 10.1, 4.0, 3.6, 3.2, 2.3, 1.4, 0.8, 0.5, 0.2].map(
          (e) => e * 2,
        ),
      },
    ],
    options: {
      chart: {
        height: 360,
        type: "bar",
      },
      plotOptions: {
        bar: {
          borderRadius: 10,
          dataLabels: {
            position: "top", // top, center, bottom
          },
        },
      },
      dataLabels: {
        enabled: true,
        formatter: function (val: any) {
          return val;
        },
        offsetY: -20,
        style: {
          fontSize: "12x",
          colors: ["#304758"],
        },
      },

      xaxis: {
        categories: [
          "Jan",
          "Fev",
          "Mar",
          "Avr",
          "Mai",
          "Jun",
          "Jul",
          "Aou",
          "Sep",
          "Oct",
          "Nov",
          "Dec",
        ],
        position: "top",
        axisBorder: {
          show: false,
        },
        axisTicks: {
          show: false,
        },
        crosshairs: {
          fill: {
            type: "gradient",
            gradient: {
              colorFrom: "#D8E3F0",
              colorTo: "#BED1E6",
              stops: [0, 100],
              opacityFrom: 0.4,
              opacityTo: 0.5,
            },
          },
        },
        tooltip: {
          enabled: false,
        },
      },
      yaxis: {
        axisBorder: {
          show: false,
        },
        axisTicks: {
          show: false,
        },
        labels: {
          show: false,
        },
      },
      title: {
        text: "Pirogue et immigrant par mois en 2024",
        floating: true,
        offsetY: 340,
        align: "center",
        style: {
          color: "#444",
        },
      },
    },
  };
  const nationalitiesState = {
    series: [
      {
        data: [400, 430, 448],
      },
    ],
    options: {
      title: {
        text: "Top 3 nationalités en 2024",
        floating: true,
        offsetY: 0,
        align: "left",
        style: {
          color: "#444",
        },
      },
      chart: {
        type: "bar",
        height: 150,
      },
      plotOptions: {
        bar: {
          borderRadius: 4,
          borderRadiusApplication: "end",
          horizontal: true,
        },
      },
      dataLabels: {
        enabled: false,
      },
      xaxis: {
        categories: ["Afrique du sud", "Canada", "Maroc"],
      },
    },
  };

  return (
    <div className="flex flex-col">
      <Title className="mb-9">Statistiques</Title>
      <div
        id="chart"
        className="rounded-xl border border-primary bg-primaryLight p-4"
      >
        <ReactApexChart
          options={state.options as ApexOptions}
          series={state.series}
          type="bar"
          height={380}
        />
      </div>
      <div className="my-7 flex gap-x-8 self-start">
        <Select
          value={selectedAge}
          onChange={(e) => {
            setSelectedAge((e.target as any).value);
          }}
        >
          <option value="none" className="text-gray" disabled>
            Age
          </option>
          <option className="" value={"mineur"}>
            Mineur
          </option>
          <option className="" value={"majeur"}>
            Majeur
          </option>
        </Select>
        <Select
          value={selectedGenre}
          onChange={(e) => {
            setSelectedGenre((e.target as any).value);
          }}
        >
          <option value="none" className="text-gray" disabled>
            Genre
          </option>
          <option className="" value={"male"}>
            Homme
          </option>
          <option className="" value={"female"}>
            Femme
          </option>
        </Select>
        <div className="w-64">
          <SearchSelect<CountryInterface>
            value={
              selectedNationality
                ? countriesNameCache.current[selectedNationality]
                : null
            }
            onSelected={function (value): void {
              countriesNameCache.current[value.id] = value.name_fr;
              setSelectedNationality(value.id);
            }}
            placeHolder={"Nationalité"}
            search={true}
            url={"countries"}
            lookupColumn="name_fr"
          />
        </div>
        <div className="w-64">
          <SearchSelect<CountryInterface>
            value={
              selectedBirthCountry
                ? countriesNameCache.current[selectedBirthCountry]
                : null
            }
            onSelected={function (value): void {
              countriesNameCache.current[value.id] = value.name_fr;
              setSelectedBirthCountry(value.id);
            }}
            placeHolder={"Pays de naissance"}
            search={true}
            url={"countries"}
            lookupColumn="name_fr"
          />
        </div>
      </div>
      <div className=" grid w-full grid-cols-2 gap-x-10">
        <div className=" flex gap-x-10 ">
          <div className="flex flex-1 flex-col items-center rounded-xl border border-primary bg-primaryLight p-5">
            <h2 className="text-2xl font-semibold text-black">
              Total Pirogues
            </h2>
            <span className="my-auto text-4xl font-bold text-primary">20</span>
          </div>
          <div className="flex flex-1 flex-col items-center rounded-xl border border-primary bg-primaryLight p-5">
            <h2 className=" text-2xl font-semibold text-black">
              Total Immigrants
            </h2>
            <span className="my-auto text-4xl font-bold text-primary">123</span>
          </div>
        </div>
        <div className=" rounded-xl border border-primary bg-primaryLight p-5">
          <div id="chart">
            <ReactApexChart
              options={nationalitiesState.options as ApexOptions}
              series={nationalitiesState.series}
              type="bar"
              height={150}
            />
          </div>
        </div>
      </div>
    </div>
  );
}
