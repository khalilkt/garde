from .immigrant import ImmigrantList, ImmigrantDetail, PirogueImmigrantsList
from .pirogue import PirogueList, PirogueDetail, MyPirogueList
from .stats import StatsView